# hackathon-chrome-extension
Ever been lost on the internet?

# You've unzipped 
Export the folder or files onto a directory
Go to your chrome application and access the extension settings: chrome://extensions
Hit "Load Unpacked" and navigate to the directory that holds these files
Turn on the extension and start highlighting!

# Enjoy the thoughts of our mentors